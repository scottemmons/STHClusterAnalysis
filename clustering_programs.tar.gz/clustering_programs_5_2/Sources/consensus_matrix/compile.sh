g++ -o pr_consensus consensus_pr/from_partitions_to_network.cpp -O3
